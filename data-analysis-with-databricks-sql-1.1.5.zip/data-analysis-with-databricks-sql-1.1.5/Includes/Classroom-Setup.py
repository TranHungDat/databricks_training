# Databricks notebook source
# MAGIC %run ./_utility-functions

# COMMAND ----------

DA = DBAcademyHelper()

DA.install_datasets(reinstall=False)

DA.conclude_setup()

